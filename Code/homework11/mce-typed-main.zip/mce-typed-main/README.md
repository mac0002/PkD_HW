# mce-typed

Om du har problem med att få detta paket att fungera i WSL/WSL2 kan följande vara till hjälp:

> sudo apt install libxext-dev libxi-dev libx11-dev

> npm install
